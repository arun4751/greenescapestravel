const menuBtn=document.querySelector(".menu-btn"),menu=document.querySelector(".nav-menu");
menuBtn.addEventListener("click",()=>{const open=menu.classList.toggle("open");menuBtn.setAttribute("aria-expanded",open);});
document.querySelectorAll(".nav-menu a").forEach(a=>a.addEventListener("click",()=>{menu.classList.remove("open");menuBtn.setAttribute("aria-expanded","false");}));
document.getElementById("year").textContent=new Date().getFullYear();
