# Green Escapes Travel — Professional Website

This version was redesigned around the supplied Horizon Hunter / Green Escapes Travel Instagram profile.

### Included
- Professional travel-brand homepage
- Mobile-first responsive design
- Instagram, Facebook and YouTube links
- WhatsApp button using +91 80821 15451
- Destinations, journeys, gallery, about and contact sections
- Supplied profile photo used as the brand/profile visual
- Local image files so the website works immediately

### Your social links
Instagram: https://www.instagram.com/greenescapes_travel
Facebook: https://www.facebook.com/share/18Az3cL37X/
YouTube: https://m.youtube.com/@Horizon_hunter51
WhatsApp: https://wa.me/918082115451

### Replace photos
The `images` folder contains placeholders. Replace them with your own travel photos while keeping the same filenames, or edit the filenames in `style.css`.

### GitHub Pages
Upload `index.html`, `style.css`, `script.js`, and the whole `images` folder to your repository. `index.html` must be in the repository root.
