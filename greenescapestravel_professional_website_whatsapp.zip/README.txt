GREEN ESCAPES TRAVEL — PROFESSIONAL WEBSITE

Included:
- Responsive travel-company design
- Instagram, YouTube Shorts and Facebook buttons using the URLs supplied
- WhatsApp floating button + contact form
- Hero section, About, Journeys, Social and Contact sections
- Your uploaded Green Escapes image

IMPORTANT:
Before publishing, replace 91XXXXXXXXXX in index.html with the actual WhatsApp number, including country code (India example: 919876543210).
The social buttons are live links to the profiles/URLs supplied.
